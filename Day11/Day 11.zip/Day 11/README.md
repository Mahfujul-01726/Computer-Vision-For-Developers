
# 🖼️ Image Classifier Web App

A web application for classifying images using a deep learning model (VGG16). Upload an image and get instant predictions with confidence scores.

## Features
- Upload images for classification
- View prediction and confidence
- Modern, responsive UI (Bootstrap 5)
- Powered by a pre-trained VGG16 model

## Setup Instructions

### 1. Clone the Repository
```bash
git clone <your-repo-url>
cd Day 11
```

### 2. Create and Activate Conda Environment
```bash
conda create -n webapp python=3.11 -y
conda activate webapp
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Application
```bash
python app.py
```

The app will start locally. Open your browser and go to `http://127.0.0.1:5000`.

## Project Structure

```
├── app.py                # Main Flask application
├── requirements.txt      # Python dependencies
├── model/
│   └── model_vgg16.h5    # Pre-trained model file
├── static/
│   ├── css/
│   │   └── style.css     # Custom styles
│   └── uploads/          # Uploaded images
├── templates/
│   └── index.html        # Main HTML template
```

## Usage
1. Upload an image using the web interface.
2. View the predicted label and confidence score.

## Requirements
- Python 3.11
- Conda (recommended)
- Flask
- TensorFlow / Keras

## License
This project is for educational purposes.

---
Feel free to customize or extend the app for your own use!