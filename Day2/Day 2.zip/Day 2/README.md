conda create -n cvdev python=3.11 -y

conda activate cvdev 

pip install -r requirements.txt